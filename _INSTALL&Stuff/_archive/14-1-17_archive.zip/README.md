# WoWCMS

Website can be used as a front page, do not use logins/registers. They probably are insecure!

+ News can be edited through DB, adminpanel will be fixed sometime in future
+ Adminpanel login works, read INFO.txt


TODO:

.Site
- add @adminpanel back to home
- add @adminpanel news add/edit/remove etc.
- add @adminpanel account link to tc_auth

- add @mainpage account page for players
- add @mainpage create account pre 6x


![Half Outdated Main page](http://i.imgur.com/1aBUYnr.jpgg)
