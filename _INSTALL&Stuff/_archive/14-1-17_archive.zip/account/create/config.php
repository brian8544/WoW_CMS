<?php
// Database settings
define('DB_HOST', 'localhost');
define('DB_USER', 'root');
define('DB_PASS', 'ascent');
define('DB_NAME', 'auth');

// Soap settings
define('SOAP_IP', 'localhost');
define('SOAP_PORT', '7878');
define('SOAP_USER', '1#1');
define('SOAP_PASS', 'passuser');

// Misc settings
define('CHECK_FOR_DUPLICATE_EMAIL', true);
define('SITE_TITLE', "");
define('META_DESCRIPTION', "");
define('META_KEYWORDS', "");
define('META_ROBOTS', "INDEX,NOFOLLOW");
define('REALMLIST', "");
